package com.example.musicapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MessagesActivity : AppCompatActivity() {

    private lateinit var messageRecyclerView: RecyclerView
    private lateinit var messageAdapter: MessageAdapter
    private lateinit var messageInput: EditText
    private lateinit var sendButton: Button
    private lateinit var backButton: Button // Added back button

    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private val messagesList = mutableListOf<Message>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_messages)

        messageRecyclerView = findViewById(R.id.messageRecyclerView)
        messageInput = findViewById(R.id.messageInput)
        sendButton = findViewById(R.id.sendButton)
        backButton = findViewById(R.id.backButton) // Initialize backButton

        messageRecyclerView.layoutManager = LinearLayoutManager(this)
        messageAdapter = MessageAdapter(messagesList)
        messageRecyclerView.adapter = messageAdapter

        // Fetch messages initially
        fetchMessages()

        sendButton.setOnClickListener {
            val messageBody = messageInput.text.toString().trim()

            if (messageBody.isNotEmpty()) {
                val currentUser = auth.currentUser
                val currentUserEmail = currentUser?.email
                val currentUserUid = currentUser?.uid

                if (currentUserEmail != null && currentUserUid != null) {
                    // Sending the message to self for now
                    val receiverId = currentUserUid

                    sendMessage(
                        senderId = currentUserUid,
                        senderEmail = currentUserEmail,
                        receiverId = receiverId,
                        messageBody = messageBody
                    )
                }
            }
        }

        // Back button click listener
        backButton.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
            finish() // Finish MessagesActivity so it's removed from back stack
        }
    }

    // Updated sendMessage to accept senderEmail
    private fun sendMessage(senderId: String, senderEmail: String, receiverId: String, messageBody: String) {
        val timestamp = System.currentTimeMillis()
        val message = Message(
            senderId = senderId,
            receiverId = receiverId,
            senderEmail = senderEmail,
            body = messageBody,
            timestamp = timestamp
        )

        firestore.collection("messages")
            .add(message)
            .addOnSuccessListener {
                Toast.makeText(this, "Message sent!", Toast.LENGTH_SHORT).show()
                messageInput.text.clear() // Clear input
                fetchMessages()  // Refresh messages
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error sending message: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    // Function to fetch messages from Firestore
    private fun fetchMessages() {
        firestore.collection("messages")
            .orderBy("timestamp")
            .get()
            .addOnSuccessListener { result ->
                messagesList.clear()
                for (document in result) {
                    val message = document.toObject(Message::class.java)
                    messagesList.add(message)
                }
                messageAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error fetching messages: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
}
