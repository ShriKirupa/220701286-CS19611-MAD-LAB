package com.example.musicapp

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var logoutBtn: ImageButton
    private lateinit var profileInitial: TextView
    private lateinit var appName: TextView
    private lateinit var logoIcon: ImageView
    private lateinit var musicQuote: TextView
    private val quote = "“Where words fail, music speaks.”"
    private var index = 0
    private val delay: Long = 70
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        auth = FirebaseAuth.getInstance()

        logoutBtn = findViewById(R.id.logoutBtn)
        profileInitial = findViewById(R.id.profileInitial)
        appName = findViewById(R.id.appName)
        logoIcon = findViewById(R.id.logoIcon)
        musicQuote = findViewById(R.id.musicQuote)

        val currentUser = auth.currentUser
        val email = currentUser?.email ?: "U"
        profileInitial.text = email.firstOrNull()?.uppercaseChar()?.toString() ?: "U"

        // Fade-in animation
        val fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in)
        logoIcon.startAnimation(fadeIn)
        appName.startAnimation(fadeIn)

        // Navigate to DashboardActivity after animation ends
        fadeIn.setAnimationListener(object : android.view.animation.Animation.AnimationListener {
            override fun onAnimationStart(animation: android.view.animation.Animation?) {}
            override fun onAnimationRepeat(animation: android.view.animation.Animation?) {}
            override fun onAnimationEnd(animation: android.view.animation.Animation?) {
                val intent = Intent(this@HomeActivity, DashboardActivity::class.java)
                startActivity(intent)
                finish() // Optional: remove HomeActivity from backstack
            }
        })

        logoutBtn.setOnClickListener {
            auth.signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
        startTypewriterEffect()
    }
    private fun startTypewriterEffect() {
        musicQuote.text = ""
        index = 0
        handler.post(typewriterRunnable)
    }

    private val typewriterRunnable = object : Runnable {
        override fun run() {
            if (index <= quote.length) {
                musicQuote.text = quote.substring(0, index)
                index++
                handler.postDelayed(this, delay)
            }
        }
    }
}
