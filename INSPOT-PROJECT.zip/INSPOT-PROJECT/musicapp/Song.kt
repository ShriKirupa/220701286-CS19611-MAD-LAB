package com.example.musicapp

data class Song(
    val title: String,
    val artist: String,
    val cover: String,
    val preview: String
)
