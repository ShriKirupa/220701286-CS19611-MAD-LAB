package com.example.musicapp
data class Post(
    val username: String = "",
    val content: String = "",
    var documentId: String = ""
)
