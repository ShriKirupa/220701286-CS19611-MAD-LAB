package com.example.musicapp
sealed class BaseSection {
    data class SongSection(val title: String, val songs: List<Song>) : BaseSection()
    data class GenreSection(val title: String, val genres: List<Genre>) : BaseSection()
}
