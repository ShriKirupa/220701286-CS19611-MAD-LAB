package com.example.musicapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class EventAdapter(private var eventList: List<Event>) : RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    class EventViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val posterImageView: ImageView = itemView.findViewById(R.id.eventPosterImageView)
        val nameTextView: TextView = itemView.findViewById(R.id.eventNameTextView)
        val dateTextView: TextView = itemView.findViewById(R.id.eventDateTextView)
        val locationTextView: TextView = itemView.findViewById(R.id.eventLocationTextView)
        val interestButton: Button = itemView.findViewById(R.id.interestButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_event, parent, false)
        return EventViewHolder(view)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val event = eventList[position]

        holder.nameTextView.text = event.name
        holder.dateTextView.text = event.date
        holder.locationTextView.text = event.location

        val posterResId = when (event.category.lowercase()) {
            "concert" -> R.drawable.concert
            "gig" -> R.drawable.gig
            "party" -> R.drawable.party
            else -> R.drawable.concert
        }
        holder.posterImageView.setImageResource(posterResId)

        holder.interestButton.setOnClickListener {
            InterestedEventsManager.addEvent(event)
        }
    }

    override fun getItemCount(): Int {
        return eventList.size
    }

    fun submitList(newList: List<Event>) {
        eventList = newList
        notifyDataSetChanged()
    }
}
