package com.example.musicapp

object InterestedEventsManager {
    private val interestedEvents = mutableListOf<Event>()

    fun addEvent(event: Event) {
        if (!interestedEvents.contains(event)) {
            interestedEvents.add(event)
        }
    }

    fun getInterestedEvents(): List<Event> {
        return interestedEvents
    }
}
