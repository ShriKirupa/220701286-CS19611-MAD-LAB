package com.example.musicapp
data class Message(
    val senderId: String = "", // Default values for Firestore deserialization
    val receiverId: String = "",
    val senderEmail: String = "",     // <-- ADD THIS
    val body: String = "",
    val timestamp: Long = 0L
)
