package com.example.musicapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder

class DashboardActivity : AppCompatActivity() {

    private lateinit var sectionRecyclerView: RecyclerView
    private val sections = mutableListOf<BaseSection>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        sectionRecyclerView = findViewById(R.id.sectionRecyclerView)
        sectionRecyclerView.layoutManager = LinearLayoutManager(this)
        sectionRecyclerView.adapter = SectionAdapter(sections)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_music -> {
                    true
                }
                R.id.nav_messages -> {
                    startActivity(Intent(this, MessagesActivity::class.java))
                    true
                }
                R.id.nav_events -> {
                    startActivity(Intent(this, EventsActivity::class.java))
                    true
                }
                R.id.nav_community -> {
                    startActivity(Intent(this, CommunityActivity::class.java))
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                else -> false
            }
        }

        fetchAllSections()
    }

    private fun fetchAllSections() {
        fetchSongs("ar rahman", "Top Hits")
        fetchSongs("selena gomez", "Trending Now")
        fetchSongs("yuvan shankar raja", "New Releases")
        fetchSongs("shreya ghosal","OG Hits")
        fetchSongs("Jonita gandhi","Favorite Hits")
        fetchSongs("Hip Hop tamizha","The Gangaster")
        addGenreSection()
    }

    private fun addGenreSection() {
        val genres = listOf(
            Genre("Tamil", R.drawable.tamil),
            Genre("Hindi", R.drawable.hindi),
            Genre("Malayalam", R.drawable.malayalam),
            Genre("K-Pop", R.drawable.kpop),
            Genre("Rock", R.drawable.rock)
        )
        val genreSection = BaseSection.GenreSection("Languages & Genres", genres)
        runOnUiThread {
            sections.add(genreSection)
            sectionRecyclerView.adapter?.notifyItemInserted(sections.size - 1)
        }
    }

    private fun fetchSongs(query: String, sectionTitle: String) {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://itunes.apple.com/search?term=$encoded&entity=song"
        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@DashboardActivity, "Failed to load $sectionTitle", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let {
                    val json = JSONObject(it)
                    val results = json.getJSONArray("results")
                    val songs = mutableListOf<Song>()

                    for (i in 0 until results.length()) {
                        val item = results.getJSONObject(i)
                        val title = item.optString("trackName", "Unknown")
                        val artist = item.optString("artistName", "Unknown")
                        val cover = item.optString("artworkUrl100", "")
                        val preview = item.optString("previewUrl", "")
                        songs.add(Song(title, artist, cover, preview))
                    }

                    val section = BaseSection.SongSection(sectionTitle, songs)

                    runOnUiThread {
                        sections.add(section)
                        sectionRecyclerView.adapter?.notifyItemInserted(sections.size - 1)
                    }
                }
            }
        })
    }
}
