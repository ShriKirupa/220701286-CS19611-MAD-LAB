package com.example.musicapp

data class Event(
    val name: String,
    val date: String,
    val location: String,
    val category: String
)
