package com.example.musicapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class CommunityActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var postList: ArrayList<Post>
    private lateinit var adapter: PostAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_community)

        val backButton = findViewById<Button>(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }

        val postEditText = findViewById<EditText>(R.id.postEditText)
        val postButton = findViewById<Button>(R.id.postButton)
        val recyclerView = findViewById<RecyclerView>(R.id.postRecyclerView)

        db = FirebaseFirestore.getInstance()
        postList = arrayListOf()
        adapter = PostAdapter(
            onDeleteClick = { post ->
                post.documentId?.let { id ->
                    db.collection("community_posts").document(id).delete()
                        .addOnSuccessListener {
                            Toast.makeText(this, "Post deleted", Toast.LENGTH_SHORT).show()
                            fetchPosts()
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, "Failed to delete post", Toast.LENGTH_SHORT).show()
                        }
                }
            }
        )

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        postButton.setOnClickListener {
            val content = postEditText.text.toString().trim()
            if (content.isNotEmpty()) {
                val postMap = hashMapOf(
                    "username" to "Anonymous",
                    "content" to content,
                    "timestamp" to System.currentTimeMillis()
                )
                db.collection("community_posts").add(postMap)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Posted!", Toast.LENGTH_SHORT).show()
                        postEditText.text.clear()
                        fetchPosts() // always refresh from Firestore after adding
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Failed to post", Toast.LENGTH_SHORT).show()
                    }
            }
        }

        fetchPosts()
    }

    private fun fetchPosts() {
        db.collection("community_posts")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .get()
            .addOnSuccessListener { result ->
                postList.clear()
                for (document in result) {
                    val post = document.toObject(Post::class.java)
                    post.documentId = document.id
                    postList.add(post)
                }
                adapter.submitList(postList.toList())
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to load posts", Toast.LENGTH_SHORT).show()
            }
    }
}
