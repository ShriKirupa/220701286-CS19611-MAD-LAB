package com.example.musicapp

data class Genre(
    val name: String,
    val imageResId: Int // For now using local drawable (you can also use URLs if needed)
)
