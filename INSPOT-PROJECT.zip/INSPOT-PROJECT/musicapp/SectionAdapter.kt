package com.example.musicapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class SectionAdapter(private val sections: List<BaseSection>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_SONG = 0
        private const val TYPE_GENRE = 1
    }

    override fun getItemViewType(position: Int): Int {
        return when (sections[position]) {
            is BaseSection.SongSection -> TYPE_SONG
            is BaseSection.GenreSection -> TYPE_GENRE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_SONG) {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_section, parent, false)
            SongSectionViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_section, parent, false)
            GenreSectionViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val section = sections[position]
        if (holder is SongSectionViewHolder && section is BaseSection.SongSection) {
            holder.sectionTitle.text = section.title
            holder.songsRecyclerView.layoutManager =
                LinearLayoutManager(holder.itemView.context, LinearLayoutManager.HORIZONTAL, false)
            holder.songsRecyclerView.adapter = SongAdapter(section.songs)
        } else if (holder is GenreSectionViewHolder && section is BaseSection.GenreSection) {
            holder.sectionTitle.text = section.title
            holder.songsRecyclerView.layoutManager =
                LinearLayoutManager(holder.itemView.context, LinearLayoutManager.HORIZONTAL, false)
            holder.songsRecyclerView.adapter = GenreAdapter(section.genres)
        }
    }

    override fun getItemCount(): Int = sections.size

    inner class SongSectionViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val sectionTitle: TextView = view.findViewById(R.id.sectionTitle)
        val songsRecyclerView: RecyclerView = view.findViewById(R.id.songsRecyclerView)
    }

    inner class GenreSectionViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val sectionTitle: TextView = view.findViewById(R.id.sectionTitle)
        val songsRecyclerView: RecyclerView = view.findViewById(R.id.songsRecyclerView)
    }
}

