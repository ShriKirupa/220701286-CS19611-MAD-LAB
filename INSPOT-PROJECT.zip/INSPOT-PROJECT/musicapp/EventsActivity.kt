package com.example.musicapp

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class EventsActivity : AppCompatActivity() {

    private lateinit var eventsRecyclerView: RecyclerView
    private lateinit var eventAdapter: EventAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_events)

        val backButton = findViewById<Button>(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }

        eventsRecyclerView = findViewById(R.id.eventsRecyclerView)

        // Sample Events
        val sampleEvents = listOf(
            Event("Rock Concert", "April 30, 2025", "Chennai", "concert"),
            Event("Jazz Gig", "May 2, 2025", "Bangalore", "gig"),
            Event("Neon Party", "May 5, 2025", "Hyderabad", "party"),
            Event("Indie Rock Night", "May 7, 2025", "Mumbai", "concert"),
            Event("Electronic Dance Party", "May 10, 2025", "Goa", "party"),
            Event("Classical Music Concert", "May 15, 2025", "Delhi", "concert"),
            Event("Techno Party", "May 17, 2025", "Pune", "party"),
            Event("Jazz Fusion Concert", "May 20, 2025", "Chennai", "gig"),
            Event("Rave Party", "May 25, 2025", "Bangalore", "party"),
            Event("Live Band Performance", "May 30, 2025", "Kochi", "gig")
        )


        eventAdapter = EventAdapter(sampleEvents)

        eventsRecyclerView.layoutManager = LinearLayoutManager(this)
        eventsRecyclerView.adapter = eventAdapter
    }
}
