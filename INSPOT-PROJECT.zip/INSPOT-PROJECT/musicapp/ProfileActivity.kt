package com.example.musicapp

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth

class ProfileActivity : AppCompatActivity() {

    private lateinit var emailTextView: TextView
    private lateinit var usernameTextView: TextView
    private lateinit var profileImageView: ImageView
    private lateinit var auth: FirebaseAuth
    private lateinit var eventsRecyclerView: RecyclerView
    private lateinit var eventAdapter: EventAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        // Initialize Views
        emailTextView = findViewById(R.id.emailTextView)
        usernameTextView = findViewById(R.id.usernameTextView)
        profileImageView = findViewById(R.id.profileImageView)
        eventsRecyclerView = findViewById(R.id.eventsRecyclerView)

        // Get Current User
        val currentUser = auth.currentUser

        if (currentUser != null) {
            val email = currentUser.email
            emailTextView.text = email

            val username = email?.substringBefore("@") ?: "Username"
            usernameTextView.text = username
        } else {
            emailTextView.text = "No User"
            usernameTextView.text = "Guest"
        }

        // Setup RecyclerView
        eventsRecyclerView.layoutManager = LinearLayoutManager(this)
        eventAdapter = EventAdapter(InterestedEventsManager.getInterestedEvents())
        eventsRecyclerView.adapter = eventAdapter
    }

    override fun onResume() {
        super.onResume()
        // Refresh the event list when returning to this activity
        eventAdapter.submitList(InterestedEventsManager.getInterestedEvents())
    }
}
